
package connection;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Meyer Triana
 */
public class DBConnection {
    Connection connection;
    static String bd = "railway";
    static String port = "6652";
    static String login = "root";
    static String password = "C8MhB47twXie1zmmLbls";
    static String ip = "containers-us-west-76.railway.app";

    public DBConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://"+DBConnection.ip+":"+DBConnection.port+"/"+DBConnection.bd;
            connection = DriverManager.getConnection(url,this.login,this.password);
            System.out.println("Conexión establecida");
        } catch (Exception ex) {
            System.out.println("Error en la conexión");
        }
    }
    public Connection getConnection(){
        return connection;
    }
    
    public void desconectar (){
        connection=null;
        
    }
    
}
