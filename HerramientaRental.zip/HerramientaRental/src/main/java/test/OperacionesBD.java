
package test;
import beans.Herramientas;
import connection.DBConnection;
import java.sql.ResultSet;
import java.sql.Statement;
/**
 *
 * @author Meyer Triana
 */
public class OperacionesBD {
    public static void main(String[] args) {
    actualizarHerramienta(1,"Electrico");
    listarHerramienta();  
    }
   public static void actualizarHerramienta(int id, String genero){
       DBConnection con = new DBConnection();
       String sql="UPDATE herramienta SET genero = '"+genero+"'WHERE id ="+id;
       try {
           Statement st = con.getConnection().createStatement(); //conexion
           st.executeUpdate(sql);
       } catch (Exception ex) {
           System.out.println(ex.getMessage());
       }
       finally{
           con.desconectar();
       }
       
   } 
   public static void listarHerramienta(){
       DBConnection con = new DBConnection();
       String sql="SELECT * FROM herramienta";
       //control de errores
       try {
           Statement st = con.getConnection().createStatement(); //conexion
           ResultSet rs=st.executeQuery(sql);
           while (rs.next()){
               int id = rs.getInt("id");
               String titulo = rs.getString("titulo");
               String genero = rs.getString("genero");
               String autor = rs.getString("autor");
               int copias = rs.getInt("copias");
               boolean novedad = rs.getBoolean("novedad");
               
               Herramientas herramientas = new Herramientas(id, titulo, genero,autor, copias, novedad);
               System.out.println(herramientas.toString());
                       
           }
       } catch (Exception ex) {
           System.out.println(ex.getMessage());
       }
       finally{
           con.desconectar();
       }
       
   } 
}
